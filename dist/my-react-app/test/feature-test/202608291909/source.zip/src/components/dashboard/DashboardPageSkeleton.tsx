import { Box, Card, CardContent, Paper, Skeleton, Stack } from '@mui/material';

const SectionSkeleton = ({ rows = 3 }: { rows?: number }) => <Card variant="outlined" sx={{ height: '100%', borderRadius: 2.5 }}>
    <CardContent sx={{ p: 2.5 }}>
        <Skeleton width={90} height={28} sx={{ mb: 1.5 }} />
        <Stack spacing={1.25}>
            {Array.from({ length: rows }, (_, index) => <Box key={index}>
                <Skeleton width={`${82 - index * 8}%`} height={22} />
                <Skeleton width={`${58 - index * 5}%`} height={17} />
            </Box>)}
        </Stack>
    </CardContent>
</Card>;

export default function DashboardPageSkeleton() {
    return <Stack spacing={3} aria-label="대시보드 불러오는 중">
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box><Skeleton width={210} height={48} /><Skeleton width={360} height={24} /></Box>
            <Skeleton width={170} height={30} sx={{ borderRadius: 3 }} />
        </Box>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'repeat(2,minmax(0,1fr))', md: 'repeat(3,minmax(0,1fr))', xl: 'repeat(6,minmax(0,1fr))' }, gap: 1.5 }}>
            {Array.from({ length: 6 }, (_, index) => <Paper key={index} variant="outlined" sx={{ p: 2, borderRadius: 2.5 }}>
                <Skeleton width="55%" height={18} /><Skeleton width="75%" height={32} sx={{ mt: .5 }} /><Skeleton width="45%" height={18} />
            </Paper>)}
        </Box>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: 'minmax(280px,1fr) minmax(0,2fr)' }, gap: 2.5 }}>
            <SectionSkeleton rows={5} />
            <SectionSkeleton rows={6} />
        </Box>

        <SectionSkeleton rows={4} />

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2,minmax(0,1fr))', xl: 'repeat(3,minmax(0,1fr))' }, gap: 2.5 }}>
            <SectionSkeleton rows={4} /><SectionSkeleton rows={4} /><SectionSkeleton rows={4} />
        </Box>
    </Stack>;
}
