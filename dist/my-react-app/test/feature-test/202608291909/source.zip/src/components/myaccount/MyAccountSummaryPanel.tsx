import { Box, Stack, Typography } from '@mui/material';
import type { MyAccountSummary } from '../../types/myAccount';
import { changeColor, formatRate, formatWon } from './myAccountFormatters';

export default function MyAccountSummaryPanel({ summary, asOf }: { summary: MyAccountSummary; asOf?: string }) {
    const details = [
        ['순자산', formatWon(summary.netAssets)],
        ['예수금', formatWon(summary.cash)],
        ['출금가능', formatWon(summary.withdrawableAmount)],
        ['대출금액', formatWon(summary.loanAmount)],
    ];
    return (
        <Stack spacing={1.5}>
            <div><Typography variant={'caption'} color={'text.secondary'}>총자산</Typography><Typography variant={'h5'} sx={{ fontWeight: 900 }}>{formatWon(summary.totalAssets)}</Typography></div>
            <div><Typography variant={'caption'} color={'text.secondary'}>평가손익</Typography><Typography sx={{ fontWeight: 800, color: changeColor(summary.profitLoss) }}>{formatWon(summary.profitLoss)} ({formatRate(summary.returnRate)})</Typography></div>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2,minmax(0,1fr))', gap: 1.25 }}>
                {details.map(([label, value]) => <Box key={label}><Typography variant="caption" color="text.secondary">{label}</Typography><Typography variant="body2" sx={{ fontWeight: 800 }}>{value}</Typography></Box>)}
            </Box>
            {asOf && <Typography variant="caption" color="text.secondary">조회 기준 {new Date(asOf).toLocaleString('ko-KR')}</Typography>}
        </Stack>
    );
}
