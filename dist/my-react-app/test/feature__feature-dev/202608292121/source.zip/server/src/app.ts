import Fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { ZodError } from 'zod';
import { env } from './config/env.js';
import { FileKisTokenStore } from './auth/FileKisTokenStore.js';
import { KisTokenManager } from './auth/KisTokenManager.js';
import { KoreaInvestmentClient } from './clients/KoreaInvestmentClient.js';
import { KoreaInvestmentMarketDataProvider } from './providers/KoreaInvestmentMarketDataProvider.js';
import { TtlCache } from './cache/TtlCache.js';
import type { StockQuote } from './domain/market.js';
import type { MyAccountResponse } from './domain/account.js';
import { MarketService } from './services/MarketService.js';
import { registerMarketRoutes } from './routes/market.routes.js';
import { AppError } from './errors/AppError.js';
import { FileNhPlugTokenStore } from './auth/FileNhPlugTokenStore.js';
import { NhPlugTokenManager } from './auth/NhPlugTokenManager.js';
import { NhPlugClient } from './clients/NhPlugClient.js';
import { NhPlugMarketDataProvider } from './providers/NhPlugMarketDataProvider.js';
import { ComparingStockQuoteProvider } from './providers/ComparingStockQuoteProvider.js';
import { KoreaInvestmentAccountProvider } from './providers/KoreaInvestmentAccountProvider.js';
import { NhPlugAccountProvider } from './providers/NhPlugAccountProvider.js';
import { MyAccountService } from './services/MyAccountService.js';
import { NewsFeedService } from './services/NewsFeedService.js';
import { z } from 'zod';
import { MarketOverviewService, type MarketOverviewItem } from './services/MarketOverviewService.js';

export function buildApp() {
    const app = Fastify({
        logger: {
            transport: process.env.NODE_ENV !== 'production'
                ? {
                    target: 'pino-pretty',
                    options: {
                        colorize: true,
                        translateTime: 'SYS:yyyy-mm-dd HH:MM:ss',
                        ignore: 'pid,hostname',
                        singleLine: false,
                    },
                }
                : undefined,
            redact: [
                'req.headers.authorization',
                'req.headers.appkey',
                'req.headers.appsecret',
                'req.headers.x-client-id',
                'req.headers.x-client-secret',
            ],
        },
    });

    const kisTokenStore = new FileKisTokenStore(env.KIS_TOKEN_FILE_PATH);
    const kisTokenManager = new KisTokenManager(
        kisTokenStore,
        env.kisBaseUrl,
        env.KIS_APP_KEY,
        env.KIS_APP_SECRET,
    );
    const kisClient = new KoreaInvestmentClient(
        env.kisBaseUrl,
        env.KIS_APP_KEY,
        env.KIS_APP_SECRET,
        kisTokenManager,
    );
    const kisProvider = new KoreaInvestmentMarketDataProvider(kisClient);

    const nhPlugTokenStore = new FileNhPlugTokenStore(env.NHPLUG_TOKEN_FILE_PATH);
    const nhPlugTokenManager = new NhPlugTokenManager(
        nhPlugTokenStore,
        env.nhPlugAuthBaseUrl,
        env.NHPLUG_APP_KEY,
        env.NHPLUG_APP_SECRET,
    );
    const nhPlugClient = new NhPlugClient(
        env.nhPlugBaseUrl,
        env.NHPLUG_APP_KEY,
        env.NHPLUG_APP_SECRET,
        nhPlugTokenManager,
    );
    const nhPlugProvider = new NhPlugMarketDataProvider(nhPlugClient);

    const provider = new ComparingStockQuoteProvider(
        env.MARKET_DATA_PROVIDER,
        kisProvider,
        nhPlugProvider,
        app.log,
    );
    const marketService = new MarketService(provider, new TtlCache<StockQuote>(), env.MARKET_QUOTE_CACHE_TTL_MS);
    const marketOverviewService = new MarketOverviewService(kisClient, new TtlCache<MarketOverviewItem[]>(), env.MARKET_OVERVIEW_CACHE_TTL_MS);
    const myAccountService = new MyAccountService([
        { broker: 'KIS', provider: new KoreaInvestmentAccountProvider(kisClient, env.kisAccounts, env.KIS_ENV, env.ACCOUNT_PRIVACY_MASK_ENABLED) },
        { broker: 'NH', provider: new NhPlugAccountProvider(nhPlugClient, env.NHPLUG_ACCOUNT_NUMBER, env.NHPLUG_ENV, env.ACCOUNT_PRIVACY_MASK_ENABLED) },
    ], app.log);
    const myAccountCache = new TtlCache<MyAccountResponse>();
    const newsFeedService = new NewsFeedService({
        naverClientId: env.NAVER_NEWS_CLIENT_ID,
        naverClientSecret: env.NAVER_NEWS_CLIENT_SECRET,
        redditClientId: env.REDDIT_CLIENT_ID,
        redditClientSecret: env.REDDIT_CLIENT_SECRET,
        redditUserAgent: env.REDDIT_USER_AGENT,
        redditSubreddits: env.REDDIT_SUBREDDITS.split(','),
        newsFeeds: env.newsFeeds,
        communityFeeds: env.communityFeeds,
    });

    app.get('/api/health', async () => ({
        status: 'ok',
        marketDataProvider: env.MARKET_DATA_PROVIDER,
        providerConfigured: env.MARKET_DATA_PROVIDER === 'nhplug' ? env.nhPlugConfigured : env.kisConfigured,
        kisConfigured: env.kisConfigured,
        nhPlugConfigured: env.nhPlugConfigured,
    }));
    void registerMarketRoutes(app, marketService, marketOverviewService);
    const myAccountQuery = z.object({ market: z.enum(['ALL', 'KRX', 'NXT']).default('ALL') });
    app.get('/api/my-account', async (request) => {
        const { market } = myAccountQuery.parse(request.query);
        return myAccountCache.getOrLoad(`my-account:${market}`, env.MY_ACCOUNT_CACHE_TTL_MS, () => myAccountService.getMyAccount(market));
    });
    const newsFeedQuery = z.object({
        cursor: z.string().optional(), query: z.string().trim().max(100).optional(),
        sourceType: z.enum(['news', 'reddit', 'community', 'social']).optional(),
        sort: z.enum(['latest', 'issue']).default('latest'),
        portfolioOnly: z.enum(['true', 'false']).transform((value) => value === 'true').default(false),
    });
    app.get('/api/news-feed', async (request) => {
        const query = newsFeedQuery.parse(request.query);
        let portfolioHoldings: Array<{ name: string; code: string }> = [];
        try {
            const account = await myAccountCache.getOrLoad('my-account', env.MY_ACCOUNT_CACHE_TTL_MS, () => myAccountService.getMyAccount());
            portfolioHoldings = [...new Map(account.accounts.flatMap((snapshot) => snapshot.positions).map((position) => [
                `${position.stockCode}:${position.stockName}`,
                { name: position.stockName, code: position.stockCode },
            ])).values()];
        } catch (error) {
            app.log.warn({ error }, 'Portfolio relevance is unavailable for the news feed');
        }
        return newsFeedService.getFeed({ ...query, portfolioHoldings });
    });

    const staticRoot = path.resolve(process.cwd(), 'dist');
    if (existsSync(staticRoot)) {
        void app.register(fastifyStatic, {
            root: staticRoot,
            prefix: '/',
        });
        app.setNotFoundHandler((request, reply) => {
            if (request.method === 'GET' && request.headers.accept?.includes('text/html')) {
                return reply.sendFile('index.html');
            }
            return reply.status(404).send({ code: 'NOT_FOUND', message: 'Route not found.' });
        });
    }

    app.setErrorHandler((error, _request, reply) => {
        if (error instanceof ZodError) {
            return reply.status(400).send({ code: 'INVALID_REQUEST', message: 'Invalid request.', details: error.issues });
        }
        if (error instanceof AppError) {
            return reply.status(error.statusCode).send({ code: error.code, message: error.message });
        }
        app.log.error(error);
        return reply.status(500).send({ code: 'INTERNAL_ERROR', message: 'Unexpected server error.' });
    });

    return app;
}
