import type { KoreaInvestmentClient, KisIndexOutput } from '../clients/KoreaInvestmentClient.js';
import type { TtlCache } from '../cache/TtlCache.js';
import { AppError } from '../errors/AppError.js';

export interface MarketOverviewItem {
    id: string;
    name: string;
    value: string;
    change: number;
    changeRate?: number;
    asOf: string;
    source: 'KIS' | 'FRED';
    status: 'live' | 'daily';
}

const number = (value: string | undefined, field: string) => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) throw new AppError(`Invalid market overview field: ${field}.`, 502, 'MARKET_OVERVIEW_INVALID_RESPONSE');
    return parsed;
};

const format = (value: number, digits = 2) => new Intl.NumberFormat('ko-KR', { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value);

export class MarketOverviewService {
    private lastSuccessful?: MarketOverviewItem[];
    constructor(private readonly kis: KoreaInvestmentClient, private readonly cache: TtlCache<MarketOverviewItem[]>, private readonly ttlMs: number) {}

    getOverview(): Promise<MarketOverviewItem[]> {
        return this.cache.getOrLoad('market-overview', this.ttlMs, async () => {
            try {
                const [kospi, kosdaq, fred] = await Promise.all([
                    this.kis.getDomesticIndexQuote('0001'),
                    this.kis.getDomesticIndexQuote('1001'),
                    this.getFredIndicators(),
                ]);
                const result = [this.kisIndex('kospi', 'KOSPI', kospi), this.kisIndex('kosdaq', 'KOSDAQ', kosdaq), ...fred];
                this.lastSuccessful = result;
                return result;
            } catch (error) {
                if (this.lastSuccessful) return this.lastSuccessful;
                throw error;
            }
        });
    }

    private kisIndex(id: string, name: string, output: KisIndexOutput): MarketOverviewItem {
        const current = number(output.bstp_nmix_prpr, `${id}.current`);
        return { id, name, value: format(current), change: number(output.bstp_nmix_prdy_vrss, `${id}.change`), changeRate: number(output.bstp_nmix_prdy_ctrt, `${id}.changeRate`), asOf: new Date().toISOString(), source: 'KIS', status: 'live' };
    }

    private async getFredIndicators(): Promise<MarketOverviewItem[]> {
        const definitions = [
            { id: 'sp500', name: 'S&P 500', series: 'SP500', suffix: '' },
            { id: 'nasdaq', name: 'NASDAQ', series: 'NASDAQCOM', suffix: '' },
            { id: 'usdkrw', name: 'USD/KRW', series: 'DEXKOUS', suffix: '' },
            { id: 'us10y', name: '미국 10년물', series: 'DGS10', suffix: '%' },
        ] as const;
        return Promise.all(definitions.map(async (definition) => {
            const observations = await this.fetchFredSeries(definition.series);
            const latest = observations.at(-1);
            const previous = observations.at(-2);
            if (!latest || !previous) throw new AppError(`FRED ${definition.series} has insufficient observations.`, 502, 'FRED_INVALID_RESPONSE');
            const change = latest.value - previous.value;
            return {
                id: definition.id,
                name: definition.name,
                value: `${format(latest.value)}${definition.suffix}`,
                change,
                changeRate: definition.id === 'us10y' ? undefined : previous.value === 0 ? 0 : change / previous.value * 100,
                asOf: `${latest.date}T00:00:00Z`,
                source: 'FRED' as const,
                status: 'daily' as const,
            };
        }));
    }

    private async fetchFredSeries(series: string): Promise<Array<{ date: string; value: number }>> {
        const start = new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
        const url = new URL('https://fred.stlouisfed.org/graph/fredgraph.csv');
        url.searchParams.set('id', series);
        url.searchParams.set('cosd', start);
        const response = await fetch(url, { headers: { accept: 'text/csv' }, signal: AbortSignal.timeout(10_000) });
        if (!response.ok) throw new AppError(`FRED ${series} request failed with status ${response.status}.`, 502, 'FRED_REQUEST_FAILED');
        const rows = (await response.text()).trim().split(/\r?\n/).slice(1);
        return rows.map((row) => {
            const [date, rawValue] = row.split(',');
            return { date, value: Number(rawValue) };
        }).filter((item) => /^\d{4}-\d{2}-\d{2}$/.test(item.date) && Number.isFinite(item.value));
    }
}
