import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { MarketService } from '../services/MarketService.js';
import type { MarketOverviewService } from '../services/MarketOverviewService.js';

const paramsSchema = z.object({ symbol: z.string().regex(/^\d{6}$/) });

export async function registerMarketRoutes(app: FastifyInstance, marketService: MarketService, marketOverviewService: MarketOverviewService): Promise<void> {
    app.get('/api/market/overview', () => marketOverviewService.getOverview());
    app.get('/api/market/stocks/:symbol/quote', async (request) => {
        const { symbol } = paramsSchema.parse(request.params);
        return marketService.getStockQuote({ symbol, region: 'KR' });
    });
}
