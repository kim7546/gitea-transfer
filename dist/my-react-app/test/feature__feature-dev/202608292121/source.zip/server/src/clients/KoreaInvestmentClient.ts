import type { KisTokenManager } from '../auth/KisTokenManager.js';
import { AppError } from '../errors/AppError.js';
import type { DomesticMarket } from '../domain/account.js';

export interface KisQuoteOutput {
    hts_kor_isnm?: string;
    stck_prpr?: string;
    prdy_vrss?: string;
    prdy_ctrt?: string;
    acml_vol?: string;
}

interface KisQuoteResponse {
    rt_cd?: string;
    msg_cd?: string;
    msg1?: string;
    output?: KisQuoteOutput;
}

export interface KisIndexOutput {
    bstp_nmix_prpr?: string;
    bstp_nmix_prdy_vrss?: string;
    bstp_nmix_prdy_ctrt?: string;
}

interface KisIndexResponse {
    rt_cd?: string;
    msg_cd?: string;
    msg1?: string;
    output?: KisIndexOutput | KisIndexOutput[];
}

export interface KisBalancePosition {
    pdno?: string; prdt_name?: string; hldg_qty?: string; pchs_avg_pric?: string; prpr?: string; bfdy_cprs_icdc?: string;
}
export interface KisBalanceSummary {
    dnca_tot_amt?: string; prvs_rcdl_excc_amt?: string; tot_loan_amt?: string; tot_evlu_amt?: string; pchs_amt_smtl_amt?: string; evlu_amt_smtl_amt?: string; evlu_pfls_smtl_amt?: string; asst_icdc_erng_rt?: string;
}
interface KisBalanceResponse { rt_cd?: string; msg_cd?: string; msg1?: string; output1?: KisBalancePosition[]; output2?: KisBalanceSummary[] }

export class KoreaInvestmentClient {
    constructor(
        private readonly baseUrl: string,
        private readonly appKey: string | undefined,
        private readonly appSecret: string | undefined,
        private readonly tokenManager: KisTokenManager,
    ) {}

    async getDomesticStockQuote(symbol: string, domesticMarket: DomesticMarket = 'ALL'): Promise<KisQuoteOutput> {
        return this.requestQuote(symbol, domesticMarket, true);
    }

    async getDomesticIndexQuote(symbol: '0001' | '1001', canRetryAuthentication = true): Promise<KisIndexOutput> {
        if (!this.appKey || !this.appSecret) throw new AppError('KIS credentials are not configured on the BFF.', 503, 'KIS_NOT_CONFIGURED');
        const token = await this.tokenManager.getAccessToken();
        const url = new URL('/uapi/domestic-stock/v1/quotations/inquire-index-price', this.baseUrl);
        url.searchParams.set('FID_COND_MRKT_DIV_CODE', 'U');
        url.searchParams.set('FID_INPUT_ISCD', symbol);
        const response = await fetch(url, {
            headers: { authorization: `Bearer ${token}`, appkey: this.appKey, appsecret: this.appSecret, tr_id: 'FHPUP02100000', custtype: 'P' },
            signal: AbortSignal.timeout(10_000),
        });
        if (response.status === 401 && canRetryAuthentication) {
            await this.tokenManager.invalidate();
            return this.getDomesticIndexQuote(symbol, false);
        }
        if (!response.ok) throw new AppError(`KIS index request failed with status ${response.status}.`, 502, 'KIS_INDEX_REQUEST_FAILED');
        const body = await response.json() as KisIndexResponse;
        const output = Array.isArray(body.output) ? body.output[0] : body.output;
        if (body.rt_cd !== '0' || !output) throw new AppError(body.msg1 ?? 'KIS returned an invalid index response.', 502, body.msg_cd ?? 'KIS_INDEX_INVALID_RESPONSE');
        return output;
    }

    async getDomesticAccountBalance(accountNumber: string, productCode: string, environment: 'paper' | 'prod'): Promise<{ positions: KisBalancePosition[]; summary: KisBalanceSummary }> {
        if (!this.appKey || !this.appSecret) throw new AppError('KIS credentials are not configured on the BFF.', 503, 'KIS_NOT_CONFIGURED');
        const token = await this.tokenManager.getAccessToken();
        const url = new URL('/uapi/domestic-stock/v1/trading/inquire-balance', this.baseUrl);
        const params: Record<string, string> = { CANO: accountNumber, ACNT_PRDT_CD: productCode, AFHR_FLPR_YN: 'N', OFL_YN: '', INQR_DVSN: '02', UNPR_DVSN: '01', FUND_STTL_ICLD_YN: 'N', FNCG_AMT_AUTO_RDPT_YN: 'N', PRCS_DVSN: '00', CTX_AREA_FK100: '', CTX_AREA_NK100: '' };
        Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
        const response = await fetch(url, { headers: { authorization: `Bearer ${token}`, appkey: this.appKey, appsecret: this.appSecret, tr_id: environment === 'prod' ? 'TTTC8434R' : 'VTTC8434R', custtype: 'P' }, signal: AbortSignal.timeout(10_000) });
        if (response.status === 401) { await this.tokenManager.invalidate(); throw new AppError('KIS account token expired. Retry the request.', 401, 'KIS_AUTH_EXPIRED'); }
        if (!response.ok) throw new AppError(`KIS balance request failed with status ${response.status}.`, 502, 'KIS_BALANCE_REQUEST_FAILED');
        const body = await response.json() as KisBalanceResponse;
        if (body.rt_cd !== '0') throw new AppError(body.msg1 ?? 'KIS returned an invalid balance response.', 502, body.msg_cd ?? 'KIS_BALANCE_INVALID_RESPONSE');
        console.info('[KIS balance response]', JSON.stringify({ account: `****${accountNumber.slice(-2)}`, response: body }));
        return { positions: body.output1 ?? [], summary: body.output2?.[0] ?? {} };
    }

    private async requestQuote(symbol: string, domesticMarket: DomesticMarket, canRetryAuthentication: boolean): Promise<KisQuoteOutput> {
        if (!this.appKey || !this.appSecret) {
            throw new AppError('KIS credentials are not configured on the BFF.', 503, 'KIS_NOT_CONFIGURED');
        }

        const token = await this.tokenManager.getAccessToken();
        const url = new URL('/uapi/domestic-stock/v1/quotations/inquire-price', this.baseUrl);
        const marketDivision = domesticMarket === 'KRX' ? 'J' : domesticMarket === 'NXT' ? 'NX' : 'UN';
        url.searchParams.set('FID_COND_MRKT_DIV_CODE', marketDivision);
        url.searchParams.set('FID_INPUT_ISCD', symbol);

        const response = await fetch(url, {
            headers: {
                authorization: `Bearer ${token}`,
                appkey: this.appKey,
                appsecret: this.appSecret,
                tr_id: 'FHKST01010100',
                custtype: 'P',
            },
            signal: AbortSignal.timeout(10_000),
        });

        if (response.status === 401 && canRetryAuthentication) {
            await this.tokenManager.invalidate();
            return this.requestQuote(symbol, domesticMarket, false);
        }
        if (!response.ok) {
            throw new AppError(`KIS quote request failed with status ${response.status}.`, 502, 'KIS_REQUEST_FAILED');
        }

        const body = await response.json() as KisQuoteResponse;
        if (body.rt_cd !== '0' || !body.output) {
            throw new AppError(body.msg1 ?? 'KIS returned an invalid quote response.', 502, body.msg_cd ?? 'KIS_INVALID_RESPONSE');
        }
        return body.output;
    }
}
