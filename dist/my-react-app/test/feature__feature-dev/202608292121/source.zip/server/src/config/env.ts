import 'dotenv/config';
import { z } from 'zod';

const envSchema = z.object({
    BFF_HOST: z.string().default('127.0.0.1'),
    BFF_PORT: z.coerce.number().int().positive().default(3000),
    PORT: z.coerce.number().int().positive().optional(),
    ACCOUNT_PRIVACY_MASK_ENABLED: z.enum(['true', 'false']).transform((value) => value === 'true').default(false),
    MARKET_DATA_PROVIDER: z.enum(['kis', 'nhplug']).default('kis'),
    KIS_ENV: z.enum(['paper', 'prod']).default('paper'),
    KIS_APP_KEY: z.string().optional(),
    KIS_APP_SECRET: z.string().optional(),
    KIS_ACCOUNTS: z.preprocess((value) => value === '' ? undefined : value, z.string().optional()),
    KIS_ACCOUNT_NUMBER: z.preprocess((value) => value === '' ? undefined : value, z.string().optional()),
    KIS_ACCOUNT_PRODUCT_CODE: z.string().regex(/^\d{2}$/).default('01'),
    KIS_REST_BASE_URL: z.string().url().optional(),
    KIS_TOKEN_FILE_PATH: z.string().default('server/.runtime/kis-token.json'),
    NHPLUG_CHANNEL: z.enum(['namuh', 'n2']).default('namuh'),
    NHPLUG_ENV: z.enum(['mock', 'prod']).default('mock'),
    NHPLUG_APP_KEY: z.string().optional(),
    NHPLUG_APP_SECRET: z.string().optional(),
    NHPLUG_ACCOUNT_NUMBER: z.preprocess((value) => value === '' ? undefined : value, z.string().optional()),
    NHPLUG_REST_BASE_URL: z.string().url().optional(),
    NHPLUG_AUTH_BASE_URL: z.string().url().optional(),
    NHPLUG_TOKEN_FILE_PATH: z.string().default('server/.runtime/nhplug-token.json'),
    MARKET_QUOTE_CACHE_TTL_MS: z.coerce.number().int().nonnegative().default(2000),
    MARKET_OVERVIEW_CACHE_TTL_MS: z.coerce.number().int().nonnegative().default(60000),
    MY_ACCOUNT_CACHE_TTL_MS: z.coerce.number().int().nonnegative().default(10000),
    NAVER_NEWS_CLIENT_ID: z.string().optional(),
    NAVER_NEWS_CLIENT_SECRET: z.string().optional(),
    NEWS_RSS_FEEDS: z.preprocess((value) => value === '' ? undefined : value, z.string().optional()),
    NEWS_RSS_ALLOWED_HOSTS: z.preprocess((value) => value === '' ? undefined : value, z.string().regex(/^[A-Za-z0-9.-]+(?:,[A-Za-z0-9.-]+)*$/).optional()),
    REDDIT_CLIENT_ID: z.string().optional(),
    REDDIT_CLIENT_SECRET: z.string().optional(),
    REDDIT_USER_AGENT: z.string().min(5).default('MyAssetNews/1.0'),
    REDDIT_SUBREDDITS: z.string().regex(/^[A-Za-z0-9_]+(?:,[A-Za-z0-9_]+)*$/).default('stocks,investing,wallstreetbets,SecurityAnalysis'),
    COMMUNITY_RSS_FEEDS: z.preprocess((value) => value === '' ? undefined : value, z.string().optional()),
    COMMUNITY_RSS_ALLOWED_HOSTS: z.preprocess((value) => value === '' ? undefined : value, z.string().regex(/^[A-Za-z0-9.-]+(?:,[A-Za-z0-9.-]+)*$/).optional()),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
    throw new Error(`Invalid BFF environment: ${parsed.error.message}`);
}

const values = parsed.data;

function parseRssFeeds(feedsValue: string | undefined, allowedHostsValue: string | undefined, prefix: 'NEWS_RSS' | 'COMMUNITY_RSS') {
    if (!feedsValue) return [];
    const feedSchema = z.array(z.object({ name: z.string().trim().min(1).max(40), url: z.string().url() })).max(20);
    let decoded: unknown;
    try { decoded = JSON.parse(feedsValue); }
    catch { throw new Error(`${prefix}_FEEDS must be valid JSON.`); }
    const feeds = feedSchema.parse(decoded);
    const allowedHosts = new Set((allowedHostsValue ?? '').split(',').map((host) => host.trim().toLowerCase()).filter(Boolean));
    if (allowedHosts.size === 0) throw new Error(`${prefix}_ALLOWED_HOSTS is required when ${prefix}_FEEDS is configured.`);
    for (const feed of feeds) {
        const url = new URL(feed.url);
        if (url.protocol !== 'https:' || url.username || url.password || url.port || !allowedHosts.has(url.hostname.toLowerCase())) {
            throw new Error(`${prefix} URL is not allowed: ${feed.url}`);
        }
    }
    return feeds;
}

const newsFeeds = parseRssFeeds(values.NEWS_RSS_FEEDS, values.NEWS_RSS_ALLOWED_HOSTS, 'NEWS_RSS');
const communityFeeds = parseRssFeeds(values.COMMUNITY_RSS_FEEDS, values.COMMUNITY_RSS_ALLOWED_HOSTS, 'COMMUNITY_RSS');

const kisAccounts = (() => {
    if (!values.KIS_ACCOUNTS) {
        if (!values.KIS_ACCOUNT_NUMBER) return [];
        if (!/^\d{8}$/.test(values.KIS_ACCOUNT_NUMBER)) {
            throw new Error('KIS_ACCOUNT_NUMBER must contain exactly 8 digits. Put the final 2 digits in KIS_ACCOUNT_PRODUCT_CODE.');
        }
        return [{ accountNumber: values.KIS_ACCOUNT_NUMBER, productCode: values.KIS_ACCOUNT_PRODUCT_CODE }];
    }
    const entries = values.KIS_ACCOUNTS.split(',').map((entry) => entry.trim()).filter(Boolean);
    if (entries.length === 0 || entries.some((entry) => !/^\d{8}:\d{2}$/.test(entry))) {
        throw new Error('KIS_ACCOUNTS must be a comma-separated list in 12345678:01 format.');
    }
    return [...new Map(entries.map((entry) => {
        const [accountNumber, productCode] = entry.split(':');
        return [`${accountNumber}:${productCode}`, { accountNumber, productCode }];
    })).values()];
})();

const nhPlugHostPrefix = values.NHPLUG_CHANNEL === 'n2' ? 'n2plug' : 'nhplug';
const nhPlugBaseUrl = values.NHPLUG_REST_BASE_URL ?? (values.NHPLUG_ENV === 'prod'
    ? `https://api.${nhPlugHostPrefix}.com:8443`
    : `https://moapi.${nhPlugHostPrefix}.com:8443`);
const nhPlugAuthBaseUrl = values.NHPLUG_AUTH_BASE_URL ?? `https://api.${nhPlugHostPrefix}.com:8443`;

const allowedNhPlugHosts = new Set(['api.nhplug.com', 'moapi.nhplug.com', 'api.n2plug.com', 'moapi.n2plug.com']);
function assertSafeNhPlugUrl(value: string, field: string): void {
    const url = new URL(value);
    if (
        url.protocol !== 'https:'
        || url.port !== '8443'
        || !allowedNhPlugHosts.has(url.hostname)
        || (url.pathname !== '/' && url.pathname !== '')
    ) {
        throw new Error(`${field} must be an official NH PLUG HTTPS origin.`);
    }
}
assertSafeNhPlugUrl(nhPlugBaseUrl, 'NHPLUG_REST_BASE_URL');
assertSafeNhPlugUrl(nhPlugAuthBaseUrl, 'NHPLUG_AUTH_BASE_URL');
if (new URL(nhPlugAuthBaseUrl).hostname.startsWith('moapi.')) {
    throw new Error('NHPLUG_AUTH_BASE_URL must use an NH PLUG production API origin.');
}

export const env = {
    ...values,
    serverHost: values.PORT ? '0.0.0.0' : values.BFF_HOST,
    serverPort: values.PORT ?? values.BFF_PORT,
    kisBaseUrl: values.KIS_REST_BASE_URL ?? (values.KIS_ENV === 'prod'
        ? 'https://openapi.koreainvestment.com:9443'
        : 'https://openapivts.koreainvestment.com:29443'),
    kisConfigured: Boolean(values.KIS_APP_KEY && values.KIS_APP_SECRET),
    kisAccounts,
    kisAccountConfigured: kisAccounts.length > 0,
    nhPlugBaseUrl,
    nhPlugAuthBaseUrl,
    nhPlugConfigured: Boolean(values.NHPLUG_APP_KEY && values.NHPLUG_APP_SECRET),
    newsFeeds,
    communityFeeds,
};
