import type { MarketDataProvider } from '../api/MarketDataProvider';
import type { DashboardData } from '../types/dashboard-data';

export class MarketService {
    constructor(private readonly provider: MarketDataProvider) {}

    getMarketIndices: MarketDataProvider['getMarketIndices'] = (request) => this.provider.getMarketIndices(request);
    getStockQuote: MarketDataProvider['getStockQuote'] = (request) => this.provider.getStockQuote(request);
    getStockFinancials: MarketDataProvider['getStockFinancials'] = (request) => this.provider.getStockFinancials(request);
    getExchangeRates: MarketDataProvider['getExchangeRates'] = () => this.provider.getExchangeRates();
    getBondYields: MarketDataProvider['getBondYields'] = () => this.provider.getBondYields();
    getEconomicIndicators: MarketDataProvider['getEconomicIndicators'] = () => this.provider.getEconomicIndicators();

    async getDashboardData(): Promise<DashboardData> {
        const [indices, exchangeRates, bondYields, watchlistItems, economicEvents, marketNews] = await Promise.all([
            this.provider.getMarketIndices(),
            this.provider.getExchangeRates(),
            this.provider.getBondYields(),
            this.provider.getWatchlist(),
            this.provider.getEconomicEvents(),
            this.provider.getMarketNews(),
        ]);

        const marketOverview = [
            ...indices.map(({ id, name, value, change, changeRate, asOf, source, status }) => ({ id, name, value, change, changeRate, asOf, source, status })),
            ...exchangeRates.map(({ id, name, displayValue: value, change, changeRate, asOf, source, status }) => ({ id, name, value, change, changeRate, asOf, source, status })),
            ...bondYields.map(({ id, name, displayValue: value, change, asOf, source, status }) => ({ id, name, value, change, asOf, source, status })),
        ];
        return { marketOverview, watchlistItems, economicEvents, marketNews };
    }
}
