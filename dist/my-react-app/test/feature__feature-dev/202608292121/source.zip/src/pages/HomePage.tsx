import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import NewspaperRoundedIcon from '@mui/icons-material/NewspaperRounded';
import StarBorderRoundedIcon from '@mui/icons-material/StarBorderRounded';
import {
    Box,
    Button,
    Chip,
    Divider,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableRow,
    Typography,
} from '@mui/material';
import DashboardSection from '../components/dashboard/DashboardSection';
import DashboardPageSkeleton from '../components/dashboard/DashboardPageSkeleton';
import MarketOverview from '../components/dashboard/MarketOverview';
import DashboardHoldingsTable from '../components/dashboard/DashboardHoldingsTable';
import MyAccountSummaryPanel from '../components/myaccount/MyAccountSummaryPanel';
import RiskAlertList from '../components/risk/RiskAlertList';
import PageRefreshButton from '../components/PageRefreshButton';
import { useDashboardData } from '../hooks/useDashboardData';
import { useMyAccount } from '../hooks/useMyAccount';
import { useRiskAlerts } from '../hooks/useRiskAlerts';
import { Link } from 'react-router';

const formatNumber = (value: number) => new Intl.NumberFormat('ko-KR').format(value);
const formatRate = (value: number) => `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
const changeColor = (value: number) => value > 0 ? 'error.main' : value < 0 ? 'primary.main' : 'text.secondary';

function MoreButton() {
    return <Button component={Link} to="/myaccount" size="small" color="inherit" endIcon={<ArrowForwardRoundedIcon />} sx={{ color: 'text.secondary' }}>더보기</Button>;
}

function HomePage() {
    const { data, loading, error } = useDashboardData();
    const { myAccount, loading: myAccountLoading, error: myAccountError } = useMyAccount();
    const { evaluation: riskEvaluation, loading: riskLoading, error: riskError } = useRiskAlerts();

    if (loading || myAccountLoading || riskLoading) return <DashboardPageSkeleton />;
    if (error) return <Typography color="error">Failed to load dashboard data: {error.message}</Typography>;
    if (myAccountError) return <Typography color="error">Failed to load account assets: {myAccountError.message}</Typography>;
    if (riskError) return <Typography color="error">Failed to evaluate account risk: {riskError.message}</Typography>;
    if (!data || !myAccount || !riskEvaluation) return null;

    const { marketOverview, economicEvents, marketNews, watchlistItems } = data;
    const topHoldings = [...myAccount.items].sort((left, right) => right.marketValue - left.marketValue).slice(0, 5);

    return (
        <Stack spacing={3}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, flexDirection: { xs: 'column', md: 'row' }, gap: 1 }}>
                <Box>
                    <Stack direction="row" sx={{ alignItems: 'center' }}><Typography variant="h4" sx={{ fontWeight: 800, letterSpacing: '-0.04em' }}>투자 대시보드</Typography><PageRefreshButton /></Stack>
                    <Typography color="text.secondary" sx={{ mt: 0.5 }}>시장 흐름과 내 자산의 변화를 한눈에 확인하세요.</Typography>
                </Box>
                <Chip label="실시간 · 공식 일별 데이터" variant="outlined" size="small" />
            </Box>

            <MarketOverview indicators={marketOverview} />

            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: 'minmax(280px, 1fr) minmax(0, 2fr)' }, gap: 2.5, alignItems: 'stretch' }}>
                <DashboardSection title="내 자산" action={<Chip label="실계좌 데이터" size="small" color="success" variant="outlined" />}>
                    <MyAccountSummaryPanel summary={myAccount.summary} asOf={myAccount.asOf} />
                </DashboardSection>

                <DashboardSection title="보유 종목" action={<MoreButton />} compact>
                    <DashboardHoldingsTable items={topHoldings} />
                </DashboardSection>

            </Box>

            <DashboardSection title="투자 위험 경고" action={<Chip label={`${riskEvaluation.alerts.length}건`} size="small" color="warning" />}>
                <RiskAlertList alerts={riskEvaluation.alerts} />
            </DashboardSection>

            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, minmax(0, 1fr))', xl: 'repeat(3, minmax(0, 1fr))' }, gap: 2.5 }}>
                <DashboardSection title="관심종목" action={<StarBorderRoundedIcon color="action" fontSize="small" />} compact>
                    <Table size="small"><TableBody>{watchlistItems.map((item) => <TableRow key={item.symbol} hover><TableCell sx={{ pl: 0 }}><Typography variant="body2" style={{ fontWeight: 700 }}>{item.name}</Typography><Typography variant="caption" color="text.secondary">{item.symbol}</Typography></TableCell><TableCell align="right"><Typography variant="body2" style={{ fontWeight: 700 }}>{formatNumber(item.price)}</Typography><Typography variant="caption" sx={{ color: changeColor(item.changeRate) }}>{formatRate(item.changeRate)}</Typography></TableCell><TableCell align="right" sx={{ pr: 0 }}><Typography variant="caption" color="text.secondary">거래량</Typography><Typography variant="caption" style={{ display: 'block' }}>{formatNumber(item.volume)}</Typography></TableCell></TableRow>)}</TableBody></Table>
                </DashboardSection>

                <DashboardSection title="주요 경제 일정" action={<CalendarMonthOutlinedIcon color="action" fontSize="small" />} compact>
                    <Stack divider={<Divider flexItem />}>{economicEvents.map((event) => <Box key={event.id} sx={{ display: 'grid', gridTemplateColumns: '54px 1fr auto', gap: 1.5, alignItems: 'center', py: 1.45 }}><Box><Typography variant="body2" style={{ fontWeight: 800 }}>{event.date}</Typography><Typography variant="caption" color="text.secondary">{event.time}</Typography></Box><Box><Typography variant="body2" style={{ fontWeight: 700 }}>{event.title}</Typography><Typography variant="caption" color="text.secondary">{event.country}</Typography></Box><Chip label={event.importance} size="small" color={event.importance === '높음' ? 'error' : 'default'} variant="outlined" /></Box>)}</Stack>
                </DashboardSection>

                <DashboardSection title="주요 뉴스" action={<NewspaperRoundedIcon color="action" fontSize="small" />} compact>
                    <Stack divider={<Divider flexItem />}>{marketNews.map((news) => <Box key={news.id} sx={{ py: 1.25 }}><Typography variant="caption" color="primary.main" style={{ fontWeight: 700 }}>{news.category}</Typography><Typography variant="body2" style={{ fontWeight: 700 }} sx={{ mt: 0.35, lineHeight: 1.45 }}>{news.title}</Typography><Typography variant="caption" color="text.secondary">{news.source} · {news.publishedAt}</Typography></Box>)}</Stack>
                </DashboardSection>
            </Box>
        </Stack>
    );
}

export default HomePage;
