import type { EconomicEvent, MarketNews, WatchlistItem } from './dashboard';
export interface MarketOverviewItem {
    id: string;
    name: string;
    value: string;
    change: number;
    changeRate?: number;
    asOf?: string;
    source?: 'KIS' | 'FRED' | 'MOCK';
    status?: 'live' | 'daily' | 'mock';
}

export interface DashboardData {
    marketOverview: MarketOverviewItem[];
    watchlistItems: WatchlistItem[];
    economicEvents: EconomicEvent[];
    marketNews: MarketNews[];
}
