export type MarketRegion = 'KR' | 'US' | 'GLOBAL';
export type CurrencyCode = 'KRW' | 'USD' | string;

export interface MarketIndex {
    id: string;
    symbol: string;
    name: string;
    region: MarketRegion;
    value: string;
    change: number;
    changeRate?: number;
    asOf: string;
    source?: 'KIS' | 'FRED' | 'MOCK';
    status?: 'live' | 'daily' | 'mock';
}

export interface StockQuote {
    symbol: string;
    name: string;
    region: MarketRegion;
    currency: CurrencyCode;
    price: number;
    change: number;
    changeRate: number;
    volume: number;
    asOf: string;
}

export interface StockFinancials {
    symbol: string;
    period: { fiscalYear: number; fiscalQuarter?: number };
    currency: CurrencyCode;
    revenue: number;
    operatingIncome: number;
    netIncome: number;
    assets?: number;
    liabilities?: number;
}

export interface ExchangeRate {
    id: string;
    baseCurrency: CurrencyCode;
    quoteCurrency: CurrencyCode;
    name: string;
    rate: number;
    displayValue: string;
    change: number;
    changeRate?: number;
    asOf: string;
    source?: 'KIS' | 'FRED' | 'MOCK';
    status?: 'live' | 'daily' | 'mock';
}

export interface BondYield {
    id: string;
    name: string;
    country: string;
    maturity: string;
    yield: number;
    displayValue: string;
    change: number;
    asOf: string;
    source?: 'KIS' | 'FRED' | 'MOCK';
    status?: 'live' | 'daily' | 'mock';
}

export interface EconomicIndicator {
    id: string;
    name: string;
    country: string;
    value: number;
    unit: string;
    period: string;
    releasedAt: string;
}

export interface StockQuoteRequest { symbol: string; region?: MarketRegion }
export interface StockFinancialsRequest extends StockQuoteRequest { fiscalYear?: number; fiscalQuarter?: number }
export interface MarketIndexRequest { region?: MarketRegion }
