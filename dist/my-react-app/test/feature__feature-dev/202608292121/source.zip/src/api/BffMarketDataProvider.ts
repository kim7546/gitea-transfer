import { MockMarketDataProvider } from './MockMarketDataProvider';
import type { BondYield, ExchangeRate, MarketIndex, StockQuote, StockQuoteRequest } from '../types/market';
import type { WatchlistItem } from '../types/dashboard';
import type { MarketOverviewItem } from '../types/dashboard-data';

interface BffErrorBody {
    code?: string;
    message?: string;
}

export class BffMarketDataProvider extends MockMarketDataProvider {
    private overviewRequest?: Promise<MarketOverviewItem[]>;
    constructor(private readonly baseUrl = import.meta.env.VITE_MARKET_API_BASE_URL || '/api') {
        super();
    }

    override async getStockQuote(request: StockQuoteRequest): Promise<StockQuote> {
        if (request.region === 'US' || !/^\d{6}$/.test(request.symbol)) {
            return super.getStockQuote(request);
        }

        const response = await fetch(`${this.baseUrl}/market/stocks/${encodeURIComponent(request.symbol)}/quote`, {
            headers: { accept: 'application/json' },
            signal: AbortSignal.timeout(10_000),
        });
        if (!response.ok) {
            const body = await response.json().catch(() => ({})) as BffErrorBody;
            throw new Error(body.message || `Market BFF request failed (${response.status}).`);
        }
        return response.json() as Promise<StockQuote>;
    }

    override async getMarketIndices(): Promise<MarketIndex[]> {
        return (await this.getOverview()).filter((item) => ['kospi', 'kosdaq', 'sp500', 'nasdaq'].includes(item.id)).map((item) => ({ id: item.id, symbol: item.id, name: item.name, region: item.id === 'kospi' || item.id === 'kosdaq' ? 'KR' : 'US', value: item.value, change: item.change, changeRate: item.changeRate, asOf: item.asOf ?? new Date().toISOString(), source: item.source, status: item.status }));
    }

    override async getExchangeRates(): Promise<ExchangeRate[]> {
        const item = (await this.getOverview()).find((candidate) => candidate.id === 'usdkrw');
        if (!item) throw new Error('USD/KRW market data is unavailable.');
        return [{ id: item.id, name: item.name, baseCurrency: 'USD', quoteCurrency: 'KRW', rate: Number(item.value.replaceAll(',', '')), displayValue: item.value, change: item.change, changeRate: item.changeRate, asOf: item.asOf ?? new Date().toISOString(), source: item.source, status: item.status }];
    }

    override async getBondYields(): Promise<BondYield[]> {
        const item = (await this.getOverview()).find((candidate) => candidate.id === 'us10y');
        if (!item) throw new Error('U.S. 10-year yield data is unavailable.');
        return [{ id: item.id, name: item.name, country: 'US', maturity: '10Y', yield: Number(item.value.replace('%', '')), displayValue: item.value, change: item.change, asOf: item.asOf ?? new Date().toISOString(), source: item.source, status: item.status }];
    }

    private getOverview(): Promise<MarketOverviewItem[]> {
        if (!this.overviewRequest) {
            this.overviewRequest = fetch(`${this.baseUrl}/market/overview`, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(15_000) })
                .then(async (response) => {
                    if (!response.ok) {
                        const body = await response.json().catch(() => ({})) as BffErrorBody;
                        throw new Error(body.message || `Market overview request failed (${response.status}).`);
                    }
                    return response.json() as Promise<MarketOverviewItem[]>;
                })
                .finally(() => { this.overviewRequest = undefined; });
        }
        return this.overviewRequest;
    }

    override async getWatchlist(): Promise<WatchlistItem[]> {
        const items = await super.getWatchlist();
        return Promise.all(items.map(async (item) => {
            if (!/^\d{6}$/.test(item.symbol)) return item;
            try {
                const quote = await this.getStockQuote({ symbol: item.symbol, region: 'KR' });
                return { ...item, name: quote.name || item.name, price: quote.price, changeRate: quote.changeRate, volume: quote.volume };
            } catch {
                // Keep the dashboard usable when the local BFF or KIS credentials are unavailable.
                return item;
            }
        }));
    }
}
