import type { MarketDataProvider } from './MarketDataProvider';
import { economicEvents, marketIndicators, marketNews, watchlistItems } from '../data/dashboardMock';
import type { BondYield, EconomicIndicator, ExchangeRate, MarketIndex, MarketIndexRequest, StockFinancials, StockFinancialsRequest, StockQuote, StockQuoteRequest } from '../types/market';

const AS_OF = '2026-08-16T15:30:00+09:00';

export class MockMarketDataProvider implements MarketDataProvider {
    async getMarketIndices(request?: MarketIndexRequest): Promise<MarketIndex[]> {
        const indices = marketIndicators.slice(0, 4).map((item, index) => ({
            ...item,
            symbol: item.id.toUpperCase(),
            region: (index < 2 ? 'KR' : 'US') as MarketIndex['region'],
            asOf: AS_OF,
            source: 'MOCK' as const,
            status: 'mock' as const,
        }));
        return request?.region ? indices.filter((item) => item.region === request.region) : indices;
    }

    async getStockQuote(request: StockQuoteRequest): Promise<StockQuote> {
        const item = watchlistItems.find((quote) => quote.symbol === request.symbol);
        if (!item) throw new Error(`Mock quote not found: ${request.symbol}`);
        return { ...item, region: request.region ?? (/^\d+$/.test(item.symbol) ? 'KR' : 'US'), currency: 'KRW', change: 0, asOf: AS_OF };
    }

    async getStockFinancials(request: StockFinancialsRequest): Promise<StockFinancials> {
        return {
            symbol: request.symbol,
            period: { fiscalYear: request.fiscalYear ?? 2025, fiscalQuarter: request.fiscalQuarter },
            currency: request.region === 'US' ? 'USD' : 'KRW',
            revenue: 0,
            operatingIncome: 0,
            netIncome: 0,
        };
    }

    async getExchangeRates(): Promise<ExchangeRate[]> {
        const item = marketIndicators[4];
        return [{ ...item, baseCurrency: 'USD', quoteCurrency: 'KRW', rate: 1368.2, displayValue: item.value, asOf: AS_OF, source: 'MOCK', status: 'mock' }];
    }

    async getBondYields(): Promise<BondYield[]> {
        const item = marketIndicators[5];
        return [{ ...item, country: 'US', maturity: '10Y', yield: 4.23, displayValue: item.value, asOf: AS_OF, source: 'MOCK', status: 'mock' }];
    }

    async getEconomicIndicators(): Promise<EconomicIndicator[]> { return []; }
    async getWatchlist() { return watchlistItems; }
    async getEconomicEvents() { return economicEvents; }
    async getMarketNews() { return marketNews; }
}
