import { Box, Chip, Paper, Typography } from '@mui/material';
import type { MarketOverviewItem } from '../../types/dashboard-data';

interface MarketOverviewProps {
    indicators: MarketOverviewItem[];
}

function MarketOverview({ indicators }: MarketOverviewProps) {
    return (
        <Box
            sx={{
                display: 'grid',
                gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(3, minmax(0, 1fr))', xl: 'repeat(6, minmax(0, 1fr))' },
                gap: 1.5,
            }}
        >
            {indicators.map((indicator) => {
                const isUp = indicator.change > 0;
                const isFlat = indicator.change === 0;
                const changeColor = isFlat ? 'text.secondary' : isUp ? 'error.main' : 'primary.main';
                const prefix = isUp ? '+' : '';

                return (
                    <Paper key={indicator.id} variant="outlined" sx={{ p: 2, borderRadius: 2.5, bgcolor: 'background.paper' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1 }}>
                            <Typography variant="caption" color="text.secondary" style={{ fontWeight: 700 }}>
                                {indicator.name}
                            </Typography>
                            <Chip label={indicator.status === 'daily' ? '최근 발표' : indicator.status === 'mock' ? 'MOCK' : 'LIVE'} size="small" color={indicator.status === 'live' ? 'success' : 'default'} variant="outlined" sx={{ height: 19, fontSize: '0.6rem' }} />
                        </Box>
                        <Typography variant="h6" sx={{ mt: 1, fontWeight: 800, letterSpacing: '-0.02em' }}>
                            {indicator.value}
                        </Typography>
                        <Typography variant="caption" sx={{ color: changeColor, fontWeight: 700 }}>
                            {prefix}{indicator.change.toFixed(2)}
                            {indicator.changeRate !== undefined && ` (${prefix}${indicator.changeRate.toFixed(2)}%)`}
                        </Typography>
                    </Paper>
                );
            })}
        </Box>
    );
}

export default MarketOverview;
