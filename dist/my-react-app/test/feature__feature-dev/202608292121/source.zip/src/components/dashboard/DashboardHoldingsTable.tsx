import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import type { MyAccountItem } from '../../types/myAccount';
import CollateralRiskIndicator from '../myaccount/CollateralRiskIndicator';
import { changeColor, formatRate, formatWon } from '../myaccount/myAccountFormatters';
import NaverStockLink from '../stock/NaverStockLink';

export default function DashboardHoldingsTable({ items }: { items: MyAccountItem[] }) {
    return <TableContainer>
        <Table size="small" sx={{ minWidth: 520 }}>
            <TableHead><TableRow>
                <TableCell>종목</TableCell>
                <TableCell align="right">평가금액</TableCell>
                <TableCell align="right">담보비율</TableCell>
                <TableCell align="right">수익율</TableCell>
            </TableRow></TableHead>
            <TableBody>{items.map((item) => <TableRow key={`${item.broker}-${item.accountId}-${item.assetType ?? 'DOMESTIC_STOCK'}-${item.stockCode}-${item.averagePrice}-${item.quantity}-${item.loanAmount ?? 0}`} hover>
                <TableCell>
                    <NaverStockLink assetType={item.assetType ?? 'DOMESTIC_STOCK'} stockCode={item.stockCode}>
                        <Typography variant="body2" sx={{ fontWeight: 800 }}>{item.stockName}</Typography>
                        <Typography variant="caption" color="text.secondary">{item.stockCode}{item.currency ? ` · ${item.currency}` : ''}</Typography>
                    </NaverStockLink>
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 800 }}>{formatWon(item.marketValue)}</TableCell>
                <TableCell align="right"><Box sx={{ display: 'inline-flex', alignItems: 'center' }}>{item.loanAmount ? formatRate(item.collateralRatio ?? 0) : '-'}{item.loanAmount ? <CollateralRiskIndicator ratio={item.collateralRatio} /> : null}</Box></TableCell>
                <TableCell align="right" sx={{ color: changeColor(item.returnRate), fontWeight: 800 }}>{formatRate(item.returnRate)}</TableCell>
            </TableRow>)}</TableBody>
        </Table>
    </TableContainer>;
}
